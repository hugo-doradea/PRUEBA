public class Main extends Interfaz {

    public static void main(String[] args) {
        System.out.println("hola mundo");

        coneccion();
    }
}
